'use strict';

const PFBResults=(()=>{
    const STORE='pfb-played-match-';
    const memory=new Map();
    const formatIP=outs=>`${Math.floor(outs/3)}${outs%3?' '+outs%3+'/3':''}`;
    const scoreWord=['ソロ','2ラン','3ラン','満塁'];
    const inningLabel=(inning,side)=>`${inning}回${side===0?'表':'裏'}`;
    const pitcherId=p=>String(p.row.Index);
    const statKey=p=>`${p.row['チーム']}|${p.row['氏名']}|${p.row['背番号']}`;
    const byId=(g,id)=>g.pitchers.flat().find(p=>pitcherId(p)===id);

    function appearanceOrder(g,side) {
        const data=g.pitchingOrder?.[side] || [];
        if (data.length) return data;
        const used=g.pitchers[side].filter(p=>p.isUsed);
        return used.map(p=>({id:pitcherId(p),inning:p.appearanceInning || 1,outs:null,lead:0}))
            .sort((a,b)=>a.inning-b.inning);
    }

    function officialGame(g) {
        if (!g.called || !/降雨/.test(g.endReason || '')) return true;
        const [homeBattingOuts,awayBattingOuts]=g.pitchers.map(arms=>arms.reduce((n,p)=>n+p.outsPitched,0));
        return homeBattingOuts>=15 || awayBattingOuts>=15 && g.scores[1]>=g.scores[0];
    }

    function pickRelief(choices) {
        if (!choices.length) return null;
        const max=Math.max(...choices.map(({arm})=>arm.outsPitched));
        // 投球回の差が1回未満なら、失点、点差、登板順を比較する。
        return choices.filter(({arm})=>max-arm.outsPitched<3).sort((a,b)=>
            a.arm.chargedRuns-b.arm.chargedRuns || a.arm.runsAllowed-b.arm.runsAllowed ||
            Math.abs(a.entry.lead)-Math.abs(b.entry.lead) || a.index-b.index
        )[0].arm;
    }

    function decide(g) {
        if (!officialGame(g) || g.scores[0]===g.scores[1]) return {win:null,loss:null,save:null};
        const side=Number(g.scores[1]>g.scores[0]);
        if (g.leadingPitchers?.side!==side) return {win:null,loss:null,save:null};
        const appearances=appearanceOrder(g,side).map((entry,index)=>({entry,index,arm:byId(g,entry.id)})).filter(x=>x.arm);
        let win=byId(g,g.leadingPitchers.win);
        const loss=byId(g,g.leadingPitchers.loss);
        const innings=Math.max(0,...appearances.map(({arm})=>arm.lastInning || 0));
        if (win?.isStarter && win.outsPitched<(innings>=6?15:12)) {
            win=pickRelief(appearances.filter(x=>x.arm.isRelief));
        } else if (win?.isRelief && win.outsPitched<3 && win.runsAllowed>=2) {
            const index=appearances.findIndex(a=>a.arm===win);
            win=pickRelief(appearances.slice(index+1).filter(x=>x.arm.runsAllowed===0&&x.arm.outsPitched>0)) || win;
        }
        const last=appearances.at(-1);
        const finish=last?.arm;
        const save=finish?.isRelief && finish!==win && finish.outsPitched>=3 &&
            (last.entry.lead>0 && last.entry.lead<=3 || finish.outsPitched>=9) ? finish : null;
        return {win,loss,save};
    }

    function readLedger() {
        const ledger=new Map(memory);
        try {
            for (let i=0;i<localStorage.length;i++) {
                const key=localStorage.key(i);
                if (!key?.startsWith(STORE)) continue;
                const value=JSON.parse(localStorage.getItem(key));
                if (value && Array.isArray(value.pitchers)) ledger.set(key.slice(STORE.length),value);
            }
        } catch {}
        return ledger;
    }

    function addToTotals(totals, report, pitcherNames) {
        for (const pitcher of report.pitchers) {
            const current=totals[pitcher.key] ||= {w:0,l:0,sv:0,g:0,outs:0,h:0,k:0,bb:0,hbp:0,r:0};
            for (const key of ['w','l','sv','outs','h','k','bb','hbp','r']) current[key]+=pitcher[key] || 0;
            current.g++;
            if (pitcherNames) pitcherNames[pitcher.key]={name:pitcher.name,team:pitcher.team,id:pitcher.id};
        }
    }

    function record(g, context={}) {
        if (g.finalReport) return g.finalReport;
        const {win,loss,save}=decide(g);
        const pitchers=[0,1].flatMap(side=>appearanceOrder(g,side).flatMap(entry=>{
            const p=byId(g,entry.id);
            if (!p) return [];
            return [{...entry,side,key:statKey(p),team:teamAt(g,side),name:playerName(p.row),
                enterOuts:entry.outs,outs:p.outsPitched,h:p.hitsAllowed,k:p.strikeouts,bb:p.walks,hbp:p.hitByPitch,
                r:p.chargedRuns,w:Number(p===win),l:Number(p===loss),sv:Number(p===save),started:p.isStarter}];
        }));
        const report={id:g.matchId,teams:[g.playerTeam,g.oppTeam],scores:[...g.scores],pitchers,
            homers:g.hrEvents?.length?g.hrEvents:g.homeRuns.map(name=>({name})),
            date:context.date || '',label:context.label || '',official:officialGame(g),totals:{}};
        if (!context.season && !context.online && report.official) {
            memory.set(report.id,report);
            try { localStorage.setItem(STORE+report.id,JSON.stringify(report)); } catch {}
            for (const item of readLedger().values()) addToTotals(report.totals,item);
        }
        g.finalReport=report;
        return report;
    }

    function reportHtml(report) {
        const winner=report.scores[0]===report.scores[1]?'引き分け':`${teamShort(report.teams[Number(report.scores[1]>report.scores[0])])}が勝利`;
        const heading=report.official?winner:'降雨でノーゲーム';
        const outcomes=[['勝',report.pitchers.find(p=>p.w)],['敗',report.pitchers.find(p=>p.l)],['S',report.pitchers.find(p=>p.sv)]];
        const decisions=outcomes.filter(([,p])=>p).map(([label,p])=>{
            const total=report.totals?.[p.key];
            const count=total?`（${total.w}勝${total.l}敗${total.sv?total.sv+'S':''}）`:'';
            return `<span><b>${label}</b> ${esc(p.name)}${esc(count)}</span>`;
        }).join('');
        const columns=report.teams.map((team,side)=>{
            const roster=report.pitchers.filter(p=>p.side===side);
            const homers=report.homers.filter(h=>h.side===side);
            const hr=homers.map(h=>`<li>${esc(inningLabel(h.inning,side))}　${esc(h.name)} ${esc(scoreWord[h.runs-1]||'本塁打')}</li>`).join('');
            const rows=roster.map(p=>{
                const stamp=p.started?'先発':`（${p.inning}回${p.enterOuts==null?'':p.enterOuts+'死'}）`;
                const total=report.totals?.[p.key];
                const count=total?`${total.w}勝${total.l}敗`:'';
                return `<tr><th scope="row">${esc(p.name)}<small>${esc(stamp)}${p.w?' · 勝':p.l?' · 敗':p.sv?' · S':''}</small></th>
                    <td>${formatIP(p.outs)}</td><td>${p.h}</td><td>${p.k}</td><td>${p.r}</td><td>${esc(count||'—')}</td></tr>`;
            }).join('');
            return `<section class="report-team"><h3>${esc(teamShort(team))}</h3>
                <h4>継投</h4><table><thead><tr><th>投手</th><th>投球回</th><th>被安打</th><th>奪三振</th><th>失点</th><th>勝敗計</th></tr></thead>
                <tbody>${rows||'<tr><td colspan="6">記録なし</td></tr>'}</tbody></table>
                <h4>本塁打</h4>${hr?`<ul>${hr}</ul>`:'<p>なし</p>'}</section>`;
        }).join('');
        const legacy=report.homers.filter(h=>h.side===undefined).map(h=>esc(h.name)).join('、');
        return `<article class="match-report">
            ${report.date? `<p class="report-date">${esc(report.date)}　${esc(report.label)}</p>`:''}
            <h2>${esc(heading)}</h2>
            <div class="report-score"><span>${esc(teamShort(report.teams[0]))}</span><b>${report.scores[0]} − ${report.scores[1]}</b><span>${esc(teamShort(report.teams[1]))}</span></div>
            ${decisions?`<p class="report-decisions">${decisions}</p>`:''}
            <div class="report-teams">${columns}</div>
            ${legacy?`<p>本塁打（旧セーブ） ${legacy}</p>`:''}
        </article>`;
    }

    function applyTotals(report, totals) {
        report.totals=Object.fromEntries(report.pitchers.filter(p=>totals[p.key]).map(p=>[p.key,{...totals[p.key]}]));
    }

    return {record,decide,reportHtml,applyTotals,officialGame,addToTotals,formatIP,pitcherId,statKey};
})();
