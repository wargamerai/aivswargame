'use strict';

const PFBSeasonUI=(()=>{
    const STORE='pfb-pennant-v1';
    let season=null, data=null, tab='news', month=2, dashboardLeague='CL', statTeam='', statType='hitting';
    let busy=false;
    const view=()=>document.getElementById('season-dialog');
    const body=()=>document.getElementById('season-content');
    const teamLabel=team=>esc(teamShort(team));

    function active(){return Boolean(season)}
    function stored(){
        try { return JSON.parse(localStorage.getItem(STORE)); } catch { return null; }
    }
    function bundle(){
        return {format:'pfb-season-v1',season,roster:data,
            match:gameInst?.seasonMatch&&!gameInst.gameOver&&!gameInst.pending?exportMatch(gameInst,data,halfEndPending):null};
    }
    function autosave(){
        if(!season||gameInst?.pending)return;
        try { localStorage.setItem(STORE,JSON.stringify(bundle())); } catch {}
    }
    function save(){
        if(gameInst?.pending){reportSave('判定を終えてから保存してください。');return}
        downloadJson(bundle(),`PFB-${teamShort(season.team)}-ペナント.json`);
        reportSave('ペナントをファイルに保存しました');
    }
    function load(value){
        if(value?.format!=='pfb-season-v1'||value.season?.version!==PFBSeason.VERSION||!Array.isArray(value.roster)||
            !Array.isArray(value.season.fixtures)||!value.season.clubs?.[value.season.league]?.includes(value.season.team)){
            throw new Error('PFBのペナントファイルを読み込めません。');
        }
        if(value.match) importMatch(value.match);
        season=value.season;
        data=value.roster;
        dashboardLeague=season.league;
        statTeam=season.team;
        month=PFBSeason.dateOf(season.day).getUTCMonth();
        close();
        showGameScreen();
        if(value.match){
            resumeMatch(value.match);
            gameInst.longInjuries=season.longInjuries;
            const f=season.fixtures.find(x=>x.id===gameInst.seasonMatch?.id);
            gameInst.profiles=f?[f.away,f.home].map(team=>profile(team)):undefined;
        }else{
            gameInst=null;players=data;show('news');
        }
    }
    function leave(){
        autosave();
        if(data)players=data;
        season=null;data=null;
        close();
    }
    function start(league,team){
        season=PFBSeason.create(players,league,team);
        data=players;
        gameInst=null;
        dashboardLeague=league;
        statTeam=team;
        month=PFBSeason.dateOf(season.day).getUTCMonth();
        autosave();
        show('news');
    }
    function close(){if(view().open)view().close()}
    function show(key='news'){
        if(!season)return;
        tab=key;
        render();
        if(!view().open)view().showModal();
    }
    function standings(){
        const order=PFBSeason.rank(season,dashboardLeague);
        return `<div class="table-scroll"><table><thead><tr><th>順位</th><th>球団</th><th>試合</th><th>勝</th><th>敗</th><th>分</th><th>勝率</th><th>差</th></tr></thead><tbody>${order.map(([team,x],i)=>{
            const winRate=x.w+x.l?PFBSeason.rateText(x.w/(x.w+x.l)):'—';
            return `<tr class="${team===season.team?'my-club':''}"><td>${i+1}</td><th>${teamLabel(team)}</th><td>${x.w+x.l+x.t}</td><td>${x.w}</td><td>${x.l}</td><td>${x.t}</td><td>${winRate}</td><td>${i?PFBSeason.gb(order[0][1],x):'—'}</td></tr>`;
        }).join('')}</tbody></table></div>`;
    }
    function gameButton(f){
        const score=f.result?` ${f.result[0]}−${f.result[1]} `:' 対 ';
        return `<button type="button" class="season-fixture${[f.away,f.home].includes(season.team)?' my-club':''}" data-season="report" data-id="${esc(f.id)}"${f.result?'':' disabled'}>${teamLabel(f.away)}${score}${teamLabel(f.home)}${f.label?` <small>${esc(f.label)}</small>`:''}${f.cancelled?'（振替）':''}</button>`;
    }
    function calendar(){
        const year=PFBSeason.dateOf(season.day).getUTCFullYear();
        const list=season.fixtures.filter(f=>f.league===dashboardLeague||f.league==='日本');
        const days=new Map();
        for(const f of list){const games=days.get(f.day)||[];games.push(f);days.set(f.day,games)}
        const start=PFBSeason.dateOf(0);
        const startDate=Date.UTC(year,month,1);
        const last=new Date(Date.UTC(year,month+1,0)).getUTCDate();
        const blanks=(new Date(startDate).getUTCDay()+6)%7;
        const rows=[...Array(blanks).fill('<div></div>'),...Array.from({length:last},(_,i)=>{
            const day=Math.round((Date.UTC(year,month,i+1)-start.getTime())/86400000);
            const matches=(days.get(day)||[]).map(gameButton).join('');
            const rest=new Date(Date.UTC(year,month,i+1)).getUTCDay()===1;
            return `<div class="season-date${day===season.day?' current-date':''}"><b>${i+1}</b>${matches|| (rest?'<small>休み</small>':'')}</div>`;
        })].join('');
        return `<div class="season-calendar-head"><button type="button" data-season="month-prev">前月</button><b>${year}年${month+1}月</b><button type="button" data-season="month-next">翌月</button></div>
            <div class="season-calendar">${['月','火','水','木','金','土','日'].map(x=>'<b class="calendar-weekday">'+x+'</b>').join('')}${rows}</div>`;
    }
    function statTable(){
        const roster=[...data.filter(p=>p['チーム']===statTeam).map(p=>[rowId(p),{name:displayName(p),team:statTeam,limit:Number(p['試合数'])||0,pitcher:isPitcher(p)}]),
            ...Object.entries(season.playerInfo).filter(([,p])=>p.team===statTeam&&p.anonymous).map(([id,p])=>[id,{...p,pitcher:id.includes('/P/')}])];
        const ledger=statType.startsWith('post-')?season.postStats:season.stats;
        const arm=statType.endsWith('pitching');
        const cols=arm?[['G','試合'],['GS','先発'],['IP','投球回'],['W','勝'],['L','敗'],['SV','S'],['PH','被安打'],['PK','奪三振'],['PBB','与四球'],['PR','失点'],['SHOCK','ショック']]:
            [['G','試合'],['PA','打席'],['AB','打数'],['H','安打'],['AVG','打率'],['2B','二塁打'],['3B','三塁打'],['HR','本塁打'],['RBI','打点'],['R','得点'],['BB','四球'],['SO','三振'],['SB','盗塁']];
        const selected=roster.filter(([id,p])=>p.pitcher===arm || (arm?ledger[id]?.PG:ledger[id]?.PA))
            .sort(([a],[b])=>(ledger[b]?.[arm?'W':'PA']||0)-(ledger[a]?.[arm?'W':'PA']||0));
        return `<div class="season-filters"><select id="season-stat-team" aria-label="成績の球団">${season.clubs[dashboardLeague].map(team=>`<option value="${esc(team)}"${team===statTeam?' selected':''}>${teamLabel(team)}</option>`).join('')}</select>
        <select id="season-stat-type" aria-label="成績の種類">${[['hitting','公式戦 打撃'],['pitching','公式戦 投手'],['post-hitting','ポストシーズン 打撃'],['post-pitching','ポストシーズン 投手']].map(([value,name])=>`<option value="${value}"${value===statType?' selected':''}>${name}</option>`).join('')}</select></div>
        <div class="table-scroll"><table><thead><tr><th>選手</th><th>上限</th>${cols.map(([,name])=>`<th>${name}</th>`).join('')}</tr></thead><tbody>${selected.map(([id,p])=>{
            const line=ledger[id]||PFBSeason.statLine();
            return `<tr><th title="${esc(p.name)}">${esc(String(p.name).replace(/ +/g,'　').split('　')[0])}</th><td>${p.limit??'—'}</td>${cols.map(([key])=>{
                if(key==='AVG')return `<td>${line.AB?PFBSeason.rateText(line.H/line.AB):'—'}</td>`;
                return `<td>${key==='IP'?PFBResults.formatIP(line.IP):line[key]}</td>`;
            }).join('')}</tr>`;
        }).join('')}</tbody></table></div>`;
    }
    function news(){
        const latest=season.news.slice(0,36);
        const today=season.fixtures.filter(f=>f.day===season.day);
        return `<div class="season-news">
            <section><h3>${esc(PFBSeason.dayText(season.day))}の対戦</h3>${today.map(gameButton).join('')}</section>
            <section><h3>野球ニュース</h3>${latest.length?`<ol>${latest.map(item=>`<li><time>${esc(PFBSeason.dayText(item.day))}</time> ${esc(item.text)}${item.fixture?` <button type="button" data-season="report" data-id="${esc(item.fixture)}">試合結果</button>`:''}</li>`).join('')}</ol>`:'<p>開幕前</p>'}</section>
        </div>`;
    }
    function render(){
        const next=PFBSeason.fixture(season);
        const live=gameInst?.seasonMatch&&!gameInst.gameOver;
        document.getElementById('season-title').textContent=`PFB ペナント　${teamShort(season.team)}`;
        document.getElementById('season-summary').textContent=season.champion?`日本一　${teamShort(season.champion)}`:
            next?`${PFBSeason.dayText(next.day)}　${next.label || '公式戦'}`:'';
        const buttons=[['news','ニュース'],['calendar','日程'],['standings','順位'],['stats','個人成績']];
        document.getElementById('season-tab-list').innerHTML=buttons.map(([key,title])=>`<button type="button" data-season="tab" data-id="${key}" aria-pressed="${key===tab}">${title}</button>`).join('');
        document.getElementById('season-toolbar').innerHTML=live?'<button type="button" data-season="close">試合に戻る</button>':
            `<button type="button" data-season="next"${!next||busy?' disabled':''}>次の試合へ</button><button type="button" data-season="sim-day"${!next||busy?' disabled':''}>1日をAIで進める</button><button type="button" data-season="save">セーブ</button><button type="button" data-season="leave">開始画面に戻る</button>`;
        const selector=`<label class="season-league">リーグ <select id="season-league"><option value="CL"${dashboardLeague==='CL'?' selected':''}>セ・リーグ</option><option value="PL"${dashboardLeague==='PL'?' selected':''}>パ・リーグ</option></select></label>`;
        body().innerHTML=(tab==='news'?'':selector)+({news,calendar,standings,stats:statTable})[tab]();
    }
    function profile(team){
        return PFBSeason.PROFILES[season.clubs[PFBSeason.leagueOf(team)].indexOf(team)%PFBSeason.PROFILES.length];
    }
    function finish(g){
        if(!season || !g.seasonMatch)return;
        const fixture=season.fixtures.find(f=>f.id===g.seasonMatch.id);
        if(fixture){PFBSeason.applyResult(season,fixture,g);autosave()}
    }
    function matchRecords(g) {
        if (!season || !g.seasonMatch) return null;
        const regular=g.seasonMatch.phase==='regular';
        const includeLive=!season.reports?.[g.seasonMatch.id] && g.finalReport?.official!==false;
        return {label:regular?'ペナント累計':'ポストシーズン累計',
            totals:regular?season.stats:season.postStats,includeLive};
    }
    function beginMatch(fixture){
        const home=fixture.home===season.team;
        const plan={...PFBSeason.roster(season,data,season.team,fixture.day,true),records:season.stats};
        const rosters=[fixture.away,fixture.home].map(team=>PFBSeason.roster(season,data,team,fixture.day));
        setup={away:fixture.away,home:fixture.home,humanSide:Number(home),versusAI:true,
            dome:PFBSeason.DOMES.has(onwardTeam(fixture.home))};
        close();
        openRosterSetup(Number(home),plan,selection=>{
            rosters[Number(home)]={...selection,profile:plan.profile};
            gameInst=PFBSeason.newGame(season,data,fixture,rosters);
            gameInst.versusAI=true;
            players=[...new Map([...data,...gameInst.lineups.flat(),...gameInst.benches.flat(),...gameInst.pitchers.flat().map(p=>p.row)].map(p=>[rowId(p),p])).values()];
            season.active=fixture.id;
            gameInst.logAdd(`試合開始　${teamShort(fixture.away)} 対 ${teamShort(fixture.home)}`,'l-inning');
            startAtBat();
            autosave();
        },()=>show('news'));
    }
    async function advance(simDay){
        if(!season||busy||gameInst?.seasonMatch&&!gameInst.gameOver)return;
        const day=PFBSeason.fixture(season)?.day;
        if(day==null)return;
        busy=true;render();
        try{
            for(let count=0;count<season.fixtures.length;count++){
                const f=PFBSeason.fixture(season);
                if(!f || simDay&&f.day!==day)break;
                if(!simDay&&[f.away,f.home].includes(season.team)){beginMatch(f);break}
                PFBSeason.applyResult(season,f,PFBSeason.simulate(PFBSeason.newGame(season,data,f)));
                if(!simDay&&f.day!==day)break;
                if(count%4===3)await new Promise(resolve=>setTimeout(resolve,0));
            }
            autosave();
        }catch(error){
            document.getElementById('season-summary').textContent=error.message;
        }finally{
            busy=false;if(view().open)render();
        }
    }
    function dispatch(target){
        const action=target.dataset.season;
        if(action==='tab'){show(target.dataset.id)}
        else if(action==='close'){close()}
        else if(action==='leave'){leave();gameInst=null;showTeamSelect()}
        else if(action==='next'||action==='sim-day'){void advance(action==='sim-day')}
        else if(action==='save'){save()}
        else if(action==='month-prev'||action==='month-next'){month=Math.max(0,Math.min(11,month+(action==='month-next'?1:-1)));render()}
        else if(action==='report'){
            const report=season.reports[target.dataset.id];
            if(report)body().innerHTML=`<button type="button" data-season="tab" data-id="${esc(tab)}">戻る</button>${PFBResults.reportHtml(report)}`;
        }
    }
    view().addEventListener('click',event=>{const action=event.target.closest('button[data-season]');if(action&&!action.disabled)dispatch(action)});
    view().addEventListener('change',event=>{
        if(event.target.id==='season-league'){dashboardLeague=event.target.value;statTeam=season.clubs[dashboardLeague][0]}
        if(event.target.id==='season-stat-team') statTeam=event.target.value;
        if(event.target.id==='season-stat-type') statType=event.target.value;
        render();
    });
    return {active,stored,load,start,leave,show,finish,save,autosave,profile,matchRecords};
})();

const resumeSeason=document.getElementById('resume-season');
resumeSeason.hidden=!PFBSeasonUI.stored();
